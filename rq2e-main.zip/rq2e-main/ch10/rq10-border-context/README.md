## `rq10-border-context` from React Quickly, 2nd ed

This folder contains the example `rq10-border-context`, which is featured in Chapter 10 of [React Quickly, 2nd ed](https://reactquickly.dev).
