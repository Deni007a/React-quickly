## `rq03-children` from React Quickly, 2nd ed

This folder contains the example `rq03-children`, which is featured in Chapter 3 of [React Quickly, 2nd ed](https://reactquickly.dev).
