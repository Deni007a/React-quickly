## `rq02-links-app` from React Quickly, 2nd ed

This folder contains the example `rq02-links-app`, which is featured in Chapter 2 of [React Quickly, 2nd ed](https://reactquickly.dev).
