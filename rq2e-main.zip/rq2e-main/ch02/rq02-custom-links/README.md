## `rq02-custom-links` from React Quickly, 2nd ed

This folder contains the example `rq02-custom-links`, which is featured in Chapter 2 of [React Quickly, 2nd ed](https://reactquickly.dev).
