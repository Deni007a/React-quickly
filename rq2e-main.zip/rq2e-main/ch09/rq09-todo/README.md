## `rq09-todo` from React Quickly, 2nd ed

This folder contains the example `rq09-todo`, which is featured in Chapter 9 of [React Quickly, 2nd ed](https://reactquickly.dev).
