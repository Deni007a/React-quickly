## `rq06-dice-roller` from React Quickly, 2nd ed

This folder contains the example `rq06-dice-roller`, which is featured in Chapter 6 of [React Quickly, 2nd ed](https://reactquickly.dev).
