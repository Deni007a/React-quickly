## `rq07-double-counter` from React Quickly, 2nd ed

This folder contains the example `rq07-double-counter`, which is featured in Chapter 7 of [React Quickly, 2nd ed](https://reactquickly.dev).
