## `rq04-menu-rest` from React Quickly, 2nd ed

This folder contains the example `rq04-menu-rest`, which is featured in Chapter 4 of [React Quickly, 2nd ed](https://reactquickly.dev).
