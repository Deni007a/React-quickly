## `rq04-gallery-function-v2` from React Quickly, 2nd ed

This folder contains the example `rq04-gallery-function-v2`, which is featured in Chapter 4 of [React Quickly, 2nd ed](https://reactquickly.dev).
