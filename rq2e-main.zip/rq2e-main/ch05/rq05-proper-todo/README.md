## `rq05-proper-todo` from React Quickly, 2nd ed

This folder contains the example `rq05-proper-todo`, which is featured in Chapter 5 of [React Quickly, 2nd ed](https://reactquickly.dev).
