## `rq05-accordion` from React Quickly, 2nd ed

This folder contains the example `rq05-accordion`, which is featured in Chapter 5 of [React Quickly, 2nd ed](https://reactquickly.dev).
