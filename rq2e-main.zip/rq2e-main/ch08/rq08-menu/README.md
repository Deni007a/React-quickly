## `rq08-menu` from React Quickly, 2nd ed

This folder contains the example `rq08-menu`, which is featured in Chapter 8 of [React Quickly, 2nd ed](https://reactquickly.dev).
