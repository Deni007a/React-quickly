## `rq08-video-player` from React Quickly, 2nd ed

This folder contains the example `rq08-video-player`, which is featured in Chapter 8 of [React Quickly, 2nd ed](https://reactquickly.dev).
