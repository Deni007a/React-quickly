## `rq11-static` from React Quickly, 2nd ed

This folder contains the example `rq11-static`, which is featured in Chapter 11 of [React Quickly, 2nd ed](https://reactquickly.dev).
