## `rq11-profile` from React Quickly, 2nd ed

This folder contains the example `rq11-profile`, which is featured in Chapter 11 of [React Quickly, 2nd ed](https://reactquickly.dev).
